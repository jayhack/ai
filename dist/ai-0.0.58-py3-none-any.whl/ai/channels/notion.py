# from notion.client import NotionClient

# Obtain the `token_v2` value by inspecting your browser cookies on a logged-in (non-guest) session on Notion.so
# notion_api = NotionClient(token_v2="secret_4BoqTGYNgboJTpzZceH2SVkt2qhnds8iDZ9zmSOg0CV")
#
# url = "https://api.notion.com/v1/pages/page_id"

# headers = {
#     "accept": "application/json",
#     "Notion-Version": "2022-06-28",
#     "Authorization": "Bearer secret_4BoqTGYNgboJTpzZceH2SVkt2qhnds8iDZ9zmSOg0CV"
# }

# response = requests.get(url, headers=headers)

# print(response.text)
