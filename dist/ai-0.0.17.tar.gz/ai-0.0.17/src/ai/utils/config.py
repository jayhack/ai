config = {
    'server_url': 'https://dev-backend.fly.dev',
    'admin_url': 'https://devai.retool.com/embedded/public/6afe1291-968e-43cd-82bd-5fa267785261#agent_name={agent_name}'
}
