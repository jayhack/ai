from .core import ai

__version__ = '0.0.45'
ai.__version__ = __version__
