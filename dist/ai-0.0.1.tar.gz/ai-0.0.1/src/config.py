config = {
    # 'server_url': 'http://localhost:8080',
    'server_url': 'https://dev-backend.fly.dev'
}
