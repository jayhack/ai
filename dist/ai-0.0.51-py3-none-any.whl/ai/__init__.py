from .core import ai

__version__ = '0.0.51'
ai.__version__ = __version__
