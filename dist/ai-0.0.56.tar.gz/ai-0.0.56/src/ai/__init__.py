from .core import ai

__version__ = '0.0.56'
ai.__version__ = __version__
