config = {
    'server_url': 'https://dev-backend.fly.dev'
}
